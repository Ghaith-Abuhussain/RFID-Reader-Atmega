RFID-With-AVR
=============

MIFARE RC522 module library for Atmel MCU. Example availablefor Atmega48.

Update
=============

* Directory structure changed
* Used AVR Makefile Version 3 
* libraries are now in lib folder	